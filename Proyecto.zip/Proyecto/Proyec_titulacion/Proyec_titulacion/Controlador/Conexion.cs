﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Proyec_titulacion.Controlador
{
    public class Conexion
    {
        public SqlDataReader dr { get; set; }
        public SqlCommand cadena_sql { get; set; }
        SqlDataAdapter adapt;
        SqlConnection conn;

        public bool Conectar()
        {
            conn = new SqlConnection();
            conn.ConnectionString = "Data source =Marcos; Initial catalog=Titulacion; Integrated security=true";
            try
            {
                conn.Open();
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Error al coonectarse a la base de datos: " + error.Message);
                return false;
            }
        }

        public void Desconectar()
        {
            conn.Close();
        }

        public void Construye_reader(String cadena)
        {
            cadena_sql = new SqlCommand();
            cadena_sql.Connection = conn;
            cadena_sql.CommandText = cadena;
        }

        public SqlDataReader Ejecuta_reader()
        {
            try
            {
                dr = cadena_sql.ExecuteReader();
                return dr;
            }
            catch (Exception error)
            {
                MessageBox.Show("Error al ejecutar el reader: " + error.Message);
                return null;
            }
        }

        public SqlCommand Contruye_command(string cadena)
        {
            cadena_sql = new SqlCommand(cadena, conn);
            return cadena_sql;
        }

        public int Ejecutnonquery()
        {
            int afectados;

            try
            {
                afectados = cadena_sql.ExecuteNonQuery();
                return afectados;
            }
            catch (Exception error)
            {
                MessageBox.Show("Error al ejecutar el reader: " + error.Message);
                return 0;
            }
        }

        public SqlDataAdapter construye_adapter(string cadena)
        {
            adapt = new SqlDataAdapter(cadena, conn);
            return adapt;
        }

        public DataRow extrae_registro(SqlDataAdapter adapter, string tabla)
        {
            DataSet ds = new DataSet();
            DataRow fila;
            try
            {
                adapter.Fill(ds, tabla);
                DataTable miTabla = ds.Tables[tabla];
                fila = miTabla.Rows[0];
                return fila;
            }
            catch (Exception error)
            {
                //MessageBox.Show("Error al extraer el registro:" + error.Message);
                return null;
            }
        }

        public DataSet consultarDataSet(string consulta)
        {
            Conectar();
            DataSet ds = new DataSet();
            SqlCommand comando = new SqlCommand();
            SqlDataAdapter adapter = new SqlDataAdapter();
            comando.CommandText = consulta;
            comando.Connection = conn;
            adapter.SelectCommand = comando;
            try
            {
                adapter.Fill(ds);
                return ds;
            }
            catch (Exception)
            {
                return null;
            }
            finally
            {
                Desconectar();
            }
        }

        public string Cargar(string consu)
        {
            SqlCommand cmd = new SqlCommand();  //Command
            SqlDataReader dr; //Leer
            string repues = "";
            try
            {
                Conectar();
                cmd.Connection = conn;
                cmd.CommandText = consu;
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    repues = dr[0].ToString(); /*Nombre de la columna a leer para el txtBox se pueden agregar más textbox dependiendo de las necesidades */
                }
            }
            catch (Exception)
            {
                repues = null;
            }
            finally
            {
                Desconectar();
            }
            return repues;
        }
    }
}