﻿function validar() {

    var acta, curp, certificado, parcial, equivalencia, titulo, tsu, fecha, nombre;

    acta = document.GetElementByTagId("<%=txtActa.ClientID%>");
    curp = document.getElementById("<%=txtCURP.ClientID%>");
    certificado = document.getElementById("<%=txtCertificado.ClientID%>");
    parcial = document.getElementById("<%=txtParcial.ClientID%>");
    equivalencia = document.getElementById("<%=txtEquivalencia.ClientID%>");
    titulo = document.getElementById("<%=txtCedula.ClientID%>");
    tsu = document.getElementById("<%=txtFolio.ClientID%>");
    fecha = document.getElementById("<%=txtFecha.ClientID%>");
    nombre = document.getElementById("<%=txtNomDictainador.ClientID%>");

    if (acta == "" || curp == "" || certificado == "" || parcial == "" || equivalencia == "" || titulo == "" || tsu == "" || fecha == "" || nombre == "") {
        alert("Verifica que los campos esten completos");
        window.history.go(-0);
        return false;
    }
}