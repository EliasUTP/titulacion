﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace Proyec_titulacion.Modelo
{
    public class Titulo
    {
        public string Status { get; set; }
        public string FechGestor { get; set; }
        public int Paquete { get; set; }
        public string FechSep { get; set; }
        public string FechDgp { get; set; }
        public string FechCon { get; set; }
        public int Cedula { get; set; }
        public string FechAlum { get; set; }
        public double Matricula { get; set; }

        public Titulo()
        {
            Status = "";
            FechGestor = "";
            Paquete = 0;
            FechSep = "";
            FechDgp = "";
            FechCon = "";
            Cedula = 0;
            FechAlum = "";
            Matricula = 0;
        }

        public Titulo(string se, string fg, int pq, string fs,string fd, string fc, int ced, string fa, double mat)
        {
            Status = se;
            FechGestor = fg;
            Paquete = pq;
            FechSep = fs;
            FechDgp = fd;
            FechCon = fc;
            Cedula = ced;
            FechAlum = fa;
            Matricula = mat;
        }

        /* Datos de retorno:
         *   1- Registros insertados correctamente
         *   0 - No se afectaron los registros
         *   -1 - No se pudo conectar a la base de datos
        */

        public int Registro()
        {
            SqlCommand comando;
            Controlador.Conexion insertar = new Controlador.Conexion();
            int regresa = 0;

            if (insertar.Conectar())
            {
                String coman = "Insert into Titulo_Cedula(Status_expe,Fech_gestor,Num_paquete,Fech_sep,Fech_dgp,Fech_conclusion,Folio_cedula,Fech_alumno,Matricula)" +
                    "values ('" + Status + "','" + FechGestor + "','" + Convert.ToInt32(Paquete) + "','" + FechSep + "','" + FechDgp + "','" + FechCon + "','" + Convert.ToInt32(Cedula) + "','"
                    + FechAlum + "','" + Matricula + "')";
                comando = insertar.Contruye_command(coman);

                if ((insertar.Ejecutnonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;

                comando.Connection.Close();
                insertar.Desconectar();
            }
            else
                regresa = -1;

            return regresa;
        }
    }
}