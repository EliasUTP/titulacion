﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Proyec_titulacion.Modelo
{
    public class Alumno
    {
        public double Matricula { get; set; }
        public String Nombre { get; set; }
        public String Apellidos { get; set; }
        public int Edad { get; set; }
        public String Sexo { get; set; }
        public String LNac { get; set; }
        public String Curp { get; set; }
        public String Correo { get; set; }
        public String Celular { get; set; }
        public String TelCasa { get; set; }
        public String Domicilio { get; set; }
        public int IdDoc { get; set; }
        public int IdDos { get; set; }
        public double IdTres { get; set; }
        public int IdCuatro { get; set; }
        public int IdEsp { get; set; }

        public Alumno()
        {
            Matricula = 0;
            Nombre = "";
            Apellidos = "";
            Edad = 0;
            Sexo = "";
            LNac = "";
            Curp = "";
            Correo = "";
            Celular = "";
            TelCasa = "";
            Domicilio = "";
            IdDoc = 0;
            IdDos = 0;
            IdTres = 0;
            IdCuatro = 0;
            IdEsp = 0;
        }

        public Alumno(double mat, String nom, String app, int ed, String sex, String ln, String curp, String email, String cel,
            String telcel, String dom, int idc, int idd, double idt, int idct, int idep)
        {
            Matricula = mat;
            Nombre = nom;
            Apellidos = app;
            Edad = ed;
            Sexo = sex;
            LNac = ln;
            Curp = curp;
            Correo = email;
            Celular = cel;
            TelCasa = telcel;
            Domicilio = dom;
            IdDoc = idc;
            IdDos = idd;
            IdTres = idt;
            IdCuatro = idct;
            IdEsp = idep;
        }

        /* Datos de retorno:
         *   1- Registros insertados correctamente
         *   0 - No se afectaron los registros
         *   -1 - No se pudo conectar a la base de datos
        */
        public int Alta()
        {
            SqlCommand coman;
            Controlador.Conexion inserta = new Controlador.Conexion();
            int regresa = 0;

            if (inserta.Conectar())
            {
                String comando = "Insert into Alumno (Matricula,Nombre,Apellidos,Edad,Sexo,Lugar_nac,Curp,Correo,TelCeluar,TelCasa,Domicilio,Id_especialidad)" +
                    "values (" + Convert.ToDouble(Matricula) + ",'" + Nombre + "','" + Apellidos + "','" + Convert.ToInt32(Edad) + "','" + Sexo + "','" + LNac + "','" + Curp + "','"
                    + Correo + "','" + Celular + "','" + TelCasa + "','" + Domicilio + "','" + IdEsp + "')";

                coman = inserta.Contruye_command(comando);

                if ((inserta.Ejecutnonquery()) != 0)
                {
                    regresa = 1;
                }

                else
                    regresa = 0;

                coman.Connection.Close();
                inserta.Desconectar();
            }
            else
                regresa = -1;

            return regresa;
        }
        public int Actua_Alumno()
        {
            SqlCommand comando;
            Controlador.Conexion actualizar = new Controlador.Conexion();
            int regresa = 0;

            if (actualizar.Conectar())
            {
                comando = actualizar.Contruye_command("update Alumno Set Nombre = '" + Nombre + "', Apellidos='"+Apellidos+"', Edad="+Edad+", Sexo='"+Sexo+ "', Lugar_nac='"+LNac+ "',Curp='"+Curp+ "',Correo='"+Correo+"'  where Matricula = " + Matricula);
                if (actualizar.Ejecutnonquery() != 0)
                    regresa = 1;
                else
                    regresa = 0;

                comando.Connection.Close();
                actualizar.Desconectar();
            }
            else
                regresa = -1;

            return regresa;
        }

        public int Actualiza_Alumno()
        {
            SqlCommand comando;
            Controlador.Conexion actualizar = new Controlador.Conexion();
            int regresa = 0;

            if (actualizar.Conectar())
            {
                comando = actualizar.Contruye_command("update Alumno Set Id_doc = " + Convert.ToInt32(IdDoc) + " where Matricula = " + Matricula);
                if (actualizar.Ejecutnonquery() != 0)
                    regresa = 1;
                else
                    regresa = 0;

                comando.Connection.Close();
                actualizar.Desconectar();
            }
            else
                regresa = -1;

            return regresa;
        }

        public int Actualiza_PasoDos()
        {
            SqlCommand comando;
            Controlador.Conexion actualizar = new Controlador.Conexion();
            int regresa = 0;

            if (actualizar.Conectar())
            {
                comando = actualizar.Contruye_command("update Alumno Set Id_Entrega = " + Convert.ToInt32(IdDos) + " where Matricula = " + Matricula);
                if (actualizar.Ejecutnonquery() != 0)
                    regresa = 1;
                else
                    regresa = 0;

                comando.Connection.Close();
                actualizar.Desconectar();
            }
            else
                regresa = -1;

            return regresa;
        }

        public int Actualiza_PasoTres()
        {
            SqlCommand comando;
            Controlador.Conexion actualizar = new Controlador.Conexion();
            int regresa = 0;

            if (actualizar.Conectar())
            {
                comando = actualizar.Contruye_command("update Alumno Set Folio = " + Convert.ToInt32(IdTres) + " where Matricula = " + Matricula);
                if (actualizar.Ejecutnonquery() != 0)
                    regresa = 1;
                else
                    regresa = 0;

                comando.Connection.Close();
                actualizar.Desconectar();
            }
            else
                regresa = -1;

            return regresa;
        }

        public int Actualiza_PasoCuatro()
        {
            SqlCommand comando;
            Controlador.Conexion actualizar = new Controlador.Conexion();
            int regresa = 0;

            if (actualizar.Conectar())
            {
                comando = actualizar.Contruye_command("update Alumno Set Id_cedula = " + Convert.ToInt32(IdCuatro) + " where Matricula = " + Matricula);
                if (actualizar.Ejecutnonquery() != 0)
                    regresa = 1;
                else
                    regresa = 0;

                comando.Connection.Close();
                actualizar.Desconectar();
            }
            else
                regresa = -1;

            return regresa;
        }

        public String regresa_nombre(double cod)
        {
            Controlador.Conexion selecciona = new Controlador.Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            //string nom;
            if (selecciona.Conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Nombre from Alumno" +
                    " where Matricula=" + cod);
                    fila = selecciona.extrae_registro(adaptador, "Alumno");
                    return fila["Nombre"].ToString();
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el còdigo");
                    return "";
                }
            }
            else
                return "";
        }
        public void buscar(double cod)
        {
            Controlador.Conexion selecciona = new Controlador.Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            //string nom;
            if (selecciona.Conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Nombre,Apellidos,Edad,Sexo,Lugar_nac,Curp,Correo,TelCasa,TelCeluar,Domicilio From Alumno" +
                    " where Matricula=" + cod);
                    fila = selecciona.extrae_registro(adaptador, "Alumno");


                    Nombre = fila["Nombre"].ToString();
                    Apellidos = fila["Apellidos"].ToString();
                    Edad = Convert.ToInt32(fila["Edad"].ToString());
                    Sexo = fila["Sexo"].ToString();
                    LNac = fila["Lugar_nac"].ToString();
                    Curp = fila["Curp"].ToString();
                    Correo = fila["Correo"].ToString();
                    TelCasa = fila["TelCasa"].ToString();
                    Celular = fila["TelCeluar"].ToString();
                    Domicilio = fila["Domicilio"].ToString();
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el còdigo");

                }
            }
                
        }

        public String regresa_apellidos(double cod)
        {
            Controlador.Conexion selecciona = new Controlador.Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            //string nom;
            if (selecciona.Conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Apellidos from Alumno" +
                    " where Matricula=" + cod);
                    fila = selecciona.extrae_registro(adaptador, "Alumno");
                    return fila["Apellidos"].ToString();
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el còdigo");
                    return "";
                }
            }
            else
                return "";
        }

        public int regresa_codigo(double mat)
        {
            Controlador.Conexion selecciona = new Controlador.Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.Conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Id_doc from PasoUno " +
                    "where Matricula = " + Matricula + ";");
                    fila = selecciona.extrae_registro(adaptador, "PasoUno");
                    return Convert.ToInt32(fila["Id_doc"]);
                }
                catch (Exception)
                {
                    //MessageBox.Show("No se encuentra el nombre");
                    return 0;
                }
            }
            else
                return -1;
        }

        public int regresa_pasados(double mat)
        {
            Controlador.Conexion selecciona = new Controlador.Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.Conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Id_Entrega from PasoDos " +
                    "where Matricula = " + Matricula + ";");
                    fila = selecciona.extrae_registro(adaptador, "PasoDos");
                    return Convert.ToInt32(fila["Id_Entrega"]);
                }
                catch (Exception)
                {
                    //MessageBox.Show("No se encuentra el nombre");
                    return 0;
                }
            }
            else
                return -1;
        }

        public int regresa_pasocuatro(double mat)
        {
            Controlador.Conexion selecciona = new Controlador.Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.Conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Id_cedula from Titulo_Cedula " +
                    "where Matricula = " + Matricula + ";");
                    fila = selecciona.extrae_registro(adaptador, "Titulo_Cedula");
                    return Convert.ToInt32(fila["Id_cedula"]);
                }
                catch (Exception)
                {
                    //MessageBox.Show("No se encuentra el nombre");
                    return 0;
                }
            }
            else
                return -1;
        }
    }
}