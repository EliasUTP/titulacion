﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace Proyec_titulacion.Modelo
{
    public class Pasotres
    {
        public double Folio { get; set; }
        public string FechExtem { get; set; }
        public int FolioServ { get; set; }
        public string FechConst { get; set; }
        public int FolioCert { get; set; }
        public string FechCert { get; set; }
        public string Fechdpo { get; set; }
        public string FechTrami { get; set; }
        public string FechEncarga { get; set; }
        public int FolioForma { get; set; }
        public string FechFirma { get; set; }
        public string Carta { get; set; }
        public string CartaSep { get; set; }
        public string Empleado { get; set; }

        public Pasotres()
        {
            Folio = 0;
            FechExtem = "";
            FolioServ = 0;
            FechConst = "";
            FolioCert = 0;
            FechCert = "";
            Fechdpo = "";
            FechTrami = "";
            FechEncarga = "";
            FolioForma = 0;
            FechFirma = "";
            Carta = "";
            CartaSep = "";
            Empleado = "";
        }

        public Pasotres( double fol, string fechex,int folserv,string fechcons, int folcert,string fechct, string fdpo, string ftram,string fechen,
            int form, string ffirma, string cart, string carsep, string empo)
        {
            Folio = fol;
            FechExtem = fechex;
            FolioServ = folserv;
            FechConst = fechcons;
            FolioCert = folcert;
            FechCert = fechct;
            Fechdpo = fdpo;
            FechTrami = ftram;
            FechEncarga = fechen;
            FolioForma = form;
            FechFirma = ffirma;
            Carta = cart;
            CartaSep = carsep;
            Empleado = empo;
        }

        /* Datos de retorno:
         *   1- Registros insertados correctamente
         *   0 - No se afectaron los registros
         *   -1 - No se pudo conectar a la base de datos
        */


        public int Alta_Registro()
        {
            SqlCommand comando;
            Controlador.Conexion inserta = new Controlador.Conexion();
            int regresa = 0;

            if (inserta.Conectar())
            {
                String coman = "Insert into PasoTres (Folio,Fech_extension,Folio_servicio,Fech_constancia,Folio_certi,Fech_certi,Fech_dpotitu,Fech_tramite,Fech_encargado,Folio_formtitu,Fech_firma,Carta_alumno,Carta_sep,Encargado)" +
                    "values (" + Convert.ToDouble(Folio) + ",'" + FechExtem + "','" + Convert.ToInt32(FolioServ) + "','" + FechConst + "','" + Convert.ToInt32(FolioCert) + "','" + FechCert + "','" + Fechdpo + "','" + FechTrami + "','" + FechEncarga + "','" +
                    Convert.ToInt32(FolioForma) + "','" + FechFirma + "','" + Carta + "','" + CartaSep + "','" + Empleado + "')";
                comando = inserta.Contruye_command(coman);

                if ((inserta.Ejecutnonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;

                comando.Connection.Close();
                inserta.Desconectar();
            }
            else
                regresa = -1;

            return regresa;
        }
    }
}