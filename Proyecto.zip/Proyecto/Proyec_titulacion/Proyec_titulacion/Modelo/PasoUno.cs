﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace Proyec_titulacion.Modelo
{
    public class PasoUno
    {
        public double id { get; set; }
        public String Acta { get; set; }
        public String CopCurp { get; set; }
        public String Certificado { get; set; }
        public String CertParcial { get; set; }
        public String StatusEqui { get; set; }
        public String CpTitulo { get; set; }
        public String Folio { get; set; }
        public DateTime FechRevision { get; set; }
        public String Nencargado { get; set; }

        public PasoUno()
        {
            Acta = "";
            CopCurp = "";
            Certificado = "";
            CertParcial = "";
            StatusEqui = "";
            CpTitulo = "";
            Folio = "";
            FechRevision = DateTime.Now;
            Nencargado = "";
            id = 0;
        }

        public PasoUno(String acnc, String cpc, String certi, String certip, String state, String cpt, String fl, DateTime fech, String ne, double ida)
        {
            Acta = acnc;
            CopCurp = cpc;
            Certificado = certi;
            CertParcial = certip;
            StatusEqui = state;
            CpTitulo = cpt;
            Folio = fl;
            FechRevision = fech;
            Nencargado = ne;
            id = ida;
        }

        /* Datos de retorno:
         *   1- Registros insertados correctamente
         *   0 - No se afectaron los registros
         *   -1 - No se pudo conectar a la base de datos
        */

        public int Registro()
        {
            SqlCommand comando;
            Controlador.Conexion ingresa = new Controlador.Conexion();
            int regresa = 0;


            if (ingresa.Conectar())
            {
                string fecha= FechRevision.Month.ToString() + "/" + FechRevision.Day.ToString() + "/" + FechRevision.Year.ToString();
                String coman = "insert into PasoUno(Acta_Nac,Cop_curp,Certificado,CertiParcial,Equivalencia,Cp_titulo,Folio_titulo,Fech_revision,Nom_encargado,Matricula)" +
                    "values ('" + Acta + "','" + CopCurp + "','" + Certificado + "','" + CertParcial + "','" + StatusEqui + "','" + CpTitulo + "','" + Folio + "','" + fecha + "','"
                    + Nencargado + "','" + Convert.ToDouble(id) + "')"; 
                comando = ingresa.Contruye_command(coman);

                if ((ingresa.Ejecutnonquery()) != 0)
                {
                    regresa = 1;
                }
                else
                    regresa = 0;

                comando.Connection.Close();
                ingresa.Desconectar();
            }
            else
                regresa = -1;

            return regresa;
        }
    }
}