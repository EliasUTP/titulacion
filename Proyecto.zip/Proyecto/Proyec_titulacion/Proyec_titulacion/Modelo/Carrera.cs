﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Proyec_titulacion.Modelo
{
    public class Carrera
    {
        public string especialidad { get; set; }
        public int idCarrera { get; set; }

        public Carrera()
        {
            especialidad = "";
            idCarrera = 0;
        }

        public Carrera(string esp, int id)
        {
            especialidad = esp;
            idCarrera = id;
        }

        public int Especialidades(DropDownList cmb)
        {
            Controlador.Conexion selecciona = new Controlador.Conexion();
            SqlDataReader lector;

            if (selecciona.Conectar())
            {
                selecciona.Construye_reader("select Nom_especia from Especialidad");
                lector = selecciona.Ejecuta_reader();
                while (lector.Read())
                    cmb.Items.Add(lector.GetString(0).ToString());

                selecciona.Desconectar();
                selecciona.dr.Close();

                return 1;
            }

            else
                return -1;
        }

        public int regresa_codigo(string mat)
        {
            Controlador.Conexion selecciona = new Controlador.Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.Conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Id_especialidad from Especialidad " +
                    "where Nom_especia = '" + mat + "'");
                    fila = selecciona.extrae_registro(adaptador, "Especialidad");
                    return Convert.ToInt32(fila["Id_especialidad"]);
                }
                catch (Exception)
                {
                    //MessageBox.Show("No se encuentra el nombre");
                    return 0;
                }
            }
            else
                return -1;
        }
    }
}