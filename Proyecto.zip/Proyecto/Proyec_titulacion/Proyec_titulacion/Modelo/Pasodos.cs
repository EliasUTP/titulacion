﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace Proyec_titulacion.Modelo
{
    public class Pasodos
    {
        public string FechAuto { get; set; }
        public string FechEntrega { get; set; }
        public string FechAcre { get; set; }
        public string Periodo { get; set; }
        public string Reporte { get; set; }
        public string Empresa { get; set; }
        public string Fotos { get; set; }
        public string Gastos { get; set; }
        public string Encargado { get; set; }
        public double Matricula { get; set; }

        public Pasodos()
        {
            FechAuto = "";
            FechEntrega = "";
            FechAcre = "";
            Periodo = "";
            Reporte = "";
            Empresa = "";
            Fotos = "";
            Gastos = "";
            Encargado = "";
            Matricula = 0;
        }

        public Pasodos(string fa, string fe, string fac, string p, string r, string emp, string fot, string g, string en, double mat)
        {
            FechAuto = fa;
            FechEntrega = fe;
            FechAcre = fac;
            Periodo = p;
            Reporte = r;
            Empresa = emp;
            Fotos = fot;
            Gastos = g;
            Encargado = en;
            Matricula = mat;
        }

        /* Datos de retorno:
         *   1- Registros insertados correctamente
         *   0 - No se afectaron los registros
         *   -1 - No se pudo conectar a la base de datos
        */

        public int alta()
        {
            SqlCommand comando;
            Controlador.Conexion inserta = new Controlador.Conexion();
            int regresa = 0;

            if (inserta.Conectar())
            {
                String coman = "Insert into PasoDos(Fech_autorizacion,Fech_entrega,Fech_acredi,Peri_estadi,Reporte_estadi,Empresa_estadi,Fotografias,Gastos,N_encargado,Matricula)" +
                    "values ('" + FechAuto + "','" + FechEntrega + "','" + FechAcre + "','" + Periodo + "','" + Reporte + "','" + Empresa + "','" + Fotos + "','" + Gastos + "','" + Encargado + "','" + Matricula + "')";
                comando = inserta.Contruye_command(coman);

                if ((inserta.Ejecutnonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;

                comando.Connection.Close();
                inserta.Desconectar();
            }
            else
                regresa = -1;

            return regresa;
        }
    }
}