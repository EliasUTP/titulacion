﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Proyec_titulacion.Modelo;

namespace Proyec_titulacion.Vista
{
    public partial class EditarAlumno : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {

        }

        protected void btmbuscar(object sender, EventArgs e)
        {
            Alumno obj = new Alumno();
            obj.buscar(Convert.ToDouble(txtMatricula.Text));
            if(obj.Nombre!="")
                {
                txtNombre.Text = obj.Nombre;
                txtApellidos.Text = obj.Apellidos;
                txtEdad.Text = obj.Edad.ToString();
                txtSexo.Text = obj.Sexo;
                txtNacimiento.Text = obj.LNac;
                txtCurp.Text = obj.Curp;
                txtEmail.Text = obj.Correo;
                txtTelefono.Text = obj.TelCasa;
                txtCelular.Text = obj.Celular;
                txtDomicilio.Text = obj.Domicilio;
            }
        }
    }
}