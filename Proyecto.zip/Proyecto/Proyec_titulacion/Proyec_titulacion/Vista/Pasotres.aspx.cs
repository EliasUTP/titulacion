﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace Proyec_titulacion.Vista
{
    public partial class Pasotres : System.Web.UI.Page
    {
        Modelo.Pasotres objTres = new Modelo.Pasotres();
        Modelo.Alumno objAlumno = new Modelo.Alumno();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            objTres.Folio = Convert.ToInt32(txtFolio.Text);
            objTres.FechExtem = txtFechEx.Text;
            objTres.FolioServ = Convert.ToInt32(txtFolioServ.Text);
            objTres.FechConst = txtFechEmision.Text;
            objTres.FolioCert = Convert.ToInt32(txtFolioTSU.Text);
            objTres.FechCert = txtFechcerti.Text;
            objTres.Fechdpo = txtFechDpotitu.Text;
            objTres.FechTrami = txtFechTramite.Text;
            objTres.FechEncarga = txtFechCarrera.Text;
            objTres.FolioForma = Convert.ToInt32(txtFormaTitu.Text);
            objTres.FechFirma = txtFechFirma.Text;
            objTres.Carta = txtCarta.Text;
            objTres.CartaSep = txtSep.Text;
            objTres.Empleado = txtNombreFirma.Text;

            int r = objTres.Alta_Registro();

            if (r == 1)
                lblDatos.Text = "Datos insertados";

            else
                if (r == 0)
                lblDatos.Text = "No se insertaron datos";

            else
                lblDatos.Text = "Error en la base de datos";


            objAlumno.Matricula = Convert.ToDouble(TextBox1.Text);
            objAlumno.IdTres = Convert.ToDouble(txtFolio.Text);
            int hr = objAlumno.Actualiza_PasoTres();
            if (hr == 1)
                MessageBox.Show("Actuliazado");
            else if (hr == 0)
                MessageBox.Show("No actulizado");
            else
                MessageBox.Show("ERROR POR SUBNORMAL");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            lblNombre.Text = objAlumno.regresa_nombre(Convert.ToDouble(TextBox1.Text));
            lblApellidos.Text = objAlumno.regresa_apellidos(Convert.ToDouble(TextBox1.Text));
        }
    }
}