﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace Proyec_titulacion.Vista
{
    public partial class FormTitulacion : System.Web.UI.Page
    {
        Modelo.Titulo objTitulo = new Modelo.Titulo();
        Modelo.Alumno objAlumno = new Modelo.Alumno();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            objTitulo.Status = txtExpediente.Text;
            objTitulo.FechGestor = txtGestor.Text;
            objTitulo.Paquete = Convert.ToInt32(txtPaquete.Text);
            objTitulo.FechSep = txtIngresoSEP.Text;
            objTitulo.FechDgp = txtIngresoDGP.Text;
            objTitulo.FechCon = txtFechConclusion.Text;
            objTitulo.Cedula = Convert.ToInt32(txtFolioCed.Text);
            objTitulo.FechAlum = txtFechEntrega.Text;
            objTitulo.Matricula = Convert.ToDouble(TextBox1.Text);

            int r = objTitulo.Registro();

            if (r == 1)
                lblDatos.Text = "Datos insertados";

            else
                if (r == 0)
                lblDatos.Text = "No se insertaron datos";

            else
                lblDatos.Text = "Error en la base de datos";


            objAlumno.Matricula = Convert.ToDouble(TextBox1.Text);
            objAlumno.IdCuatro = objAlumno.regresa_pasocuatro(Convert.ToDouble(TextBox1.Text));
            int hr = objAlumno.Actualiza_PasoCuatro();
            if (hr == 1)
                MessageBox.Show("Actuliazado");
            else if (hr == 0)
                MessageBox.Show("No actulizado");
            else
                MessageBox.Show("ERROR POR SUBNORMAL");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            lblNombre.Text = objAlumno.regresa_nombre(Convert.ToDouble(TextBox1.Text));
            lblApellidos.Text = objAlumno.regresa_apellidos(Convert.ToDouble(TextBox1.Text));
        }
    }
}