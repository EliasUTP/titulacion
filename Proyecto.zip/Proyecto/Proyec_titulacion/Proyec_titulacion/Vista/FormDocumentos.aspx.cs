﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace Proyec_titulacion.Vista
{
    public partial class FormDocumentos : System.Web.UI.Page
    {
        Modelo.PasoUno objPaso = new Modelo.PasoUno();
        Modelo.Alumno objAlumno = new Modelo.Alumno();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            objPaso.Acta = cmbActa.Text;
            objPaso.CopCurp = cmbCURP.Text;
            objPaso.Certificado = cmbCertificado.Text;
            objPaso.CertParcial = cmbParcial.Text;
            objPaso.StatusEqui = cmbEquivalencia.Text;
            objPaso.CpTitulo = cmbCedula.Text;
            objPaso.Folio = cmbFolio.Text;
            objPaso.FechRevision = Convert.ToDateTime(txtFecha.Text);
            objPaso.Nencargado = txtNomDictainador.Text;
            objPaso.id = Convert.ToDouble(TextBox1.Text);

            int r = objPaso.Registro();

            if (r == 1)
                lblInsertar.Text = "Datos insertados";

            else
                if (r == 0)
                lblInsertar.Text = "No se insertaron datos";

            else
                lblInsertar.Text = "Error en la base de datos";


            objAlumno.Matricula = Convert.ToDouble(TextBox1.Text);
            objAlumno.IdDoc = objAlumno.regresa_codigo(Convert.ToDouble(TextBox1.Text));
            int hr = objAlumno.Actualiza_Alumno();
            if (hr == 1)
                MessageBox.Show("Actuliazado");
            else if (hr == 0)
                MessageBox.Show("No actulizado");
            else
                MessageBox.Show("ERROR POR SUBNORMAL");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            lblNombre.Text = objAlumno.regresa_nombre(Convert.ToDouble(TextBox1.Text));
            lblApellidos.Text = objAlumno.regresa_apellidos(Convert.ToDouble(TextBox1.Text));
        }
    }
}