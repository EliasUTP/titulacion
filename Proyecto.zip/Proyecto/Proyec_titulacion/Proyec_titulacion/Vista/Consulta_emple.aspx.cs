﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Proyec_titulacion.Vista
{
    public partial class Consulta_emple : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Controlador.Conexion obj = new Controlador.Conexion();

            if (obj.consultarDataSet("select Nombre,Apellidos,Edad,Sexo,Lugar_nac,Curp,Correo,TelCeluar,TelCasa,Domicilio from alumno where Matricula = " + txtMatricula.Text) != null)
            {
                Grv_alumno.DataSource = obj.consultarDataSet("select Nombre,Apellidos,Edad,Sexo,Lugar_nac,Curp,Correo,TelCeluar,TelCasa,Domicilio from alumno where Matricula = " + txtMatricula.Text);
                lbl_msg.Text = "";
                Grv_alumno.DataBind();
                GridView1.DataSource = obj.consultarDataSet("select [PasoUno].[Id_doc],[Acta_Nac],[Cop_curp],[Certificado],[CertiParcial],[Equivalencia],[Cp_titulo],[Folio_titulo],[Fech_revision],[Nom_encargado] from [Alumno],[PasoUno] where [PasoUno].[Id_doc] = [Alumno].[Id_doc] and alumno.Matricula = " + txtMatricula.Text);
                GridView1.DataBind();
                GridView2.DataSource = obj.consultarDataSet("SELECT [PasoDos].[Id_Entrega],[Fech_autorizacion],[Fech_entrega],[Fech_acredi],[Peri_estadi],[Reporte_estadi],[Empresa_estadi],[Fotografias],[Gastos],[N_encargado] FROM [Alumno],[PasoDos] WHERE [PasoDos].[Id_Entrega] = [Alumno].[Id_Entrega] and alumno.Matricula = " + txtMatricula.Text);
                GridView2.DataBind();
                GridView3.DataSource = obj.consultarDataSet("SELECT [PasoTres].[Folio],[Fech_extension],[Folio_servicio],[Fech_constancia],[Folio_certi],[Fech_certi],[Fech_dpotitu],[Fech_tramite],[Fech_encargado],[Folio_formtitu],[Fech_firma],[Carta_alumno],[Carta_sep],[Encargado] FROM [PasoTres],[Alumno] where [PasoTres].[Folio] = [Alumno].[Folio] and alumno.Matricula = " + txtMatricula.Text);
                GridView3.DataBind();
                GridView4.DataSource = obj.consultarDataSet("SELECT [Titulo_Cedula].[Id_cedula],[Status_expe],[Fech_gestor],[Num_paquete],[Fech_sep],[Fech_dgp],[Fech_conclusion],[Folio_cedula],[Fech_alumno] FROM [Titulo_Cedula],[Alumno] where [Titulo_Cedula].[Id_cedula] = [Alumno].[Id_cedula] and alumno.Matricula = " + txtMatricula.Text);
                GridView4.DataBind();
            }
            else
            {
                lbl_msg.Text = "No hay registro de la matricula";
            }
        }
    }
}