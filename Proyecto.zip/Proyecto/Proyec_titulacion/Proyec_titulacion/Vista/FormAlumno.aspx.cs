﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace Proyec_titulacion.Vista
{
    public partial class FormAlumno : System.Web.UI.Page
    {
        Modelo.Alumno objAlumno = new Modelo.Alumno();
        Modelo.Carrera objCarrera = new Modelo.Carrera();
        protected void Page_Load(object sender, EventArgs e)
        {
            int r = objCarrera.Especialidades(DropDownList1);
            if (r == -1)
                MessageBox.Show("No hay");
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            objAlumno.Matricula = Convert.ToDouble(txtMatricula.Text);
            objAlumno.Nombre = txtNombre.Text;
            objAlumno.Apellidos = txtApellidos.Text;
            objAlumno.Edad = Convert.ToInt32(txtEdad.Text);
            objAlumno.Sexo = txtSexo.Text;
            objAlumno.LNac = txtNacimiento.Text;
            objAlumno.Curp = txtCurp.Text;
            objAlumno.Correo = txtEmail.Text;
            objAlumno.Celular = txtCelular.Text;
            objAlumno.TelCasa = txtTelefono.Text;
            objAlumno.Domicilio = txtDomicilio.Text;
            objAlumno.IdEsp = Convert.ToInt32(lblClave.Text);

            int r = objAlumno.Alta();

            if (r == 1)
                lblDatos.Text = "Datos insertados";

            else
                if (r == 0)
                lblDatos.Text = "No se insertaron datos";

            else
                MessageBox.Show("Error en la base de datos");
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Label1.Text = objCarrera.Regresa_codigo(DropDownList1.SelectedValue).ToString();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            lblClave.Text = objCarrera.regresa_codigo(DropDownList1.Text).ToString();
        }
    }
}