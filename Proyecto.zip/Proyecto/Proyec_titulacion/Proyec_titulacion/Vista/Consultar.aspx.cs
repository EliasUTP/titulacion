﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Proyec_titulacion.Vista
{
    public partial class Consultar : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            lbl_pas1.Text = "---";
            lbl_paso2.Text = "---";
            lbl_paso3.Text = "---";
            lbl_titu.Text = "---";
            Controlador.Conexion obj = new Controlador.Conexion();
            if (obj.consultarDataSet("select Nombre,Apellidos,Edad,Sexo,Lugar_nac,Curp,Correo,TelCeluar,TelCasa,Domicilio from alumno where Matricula = " + txtMatricula.Text) != null)
            {
                Grv_alumno.DataSource = obj.consultarDataSet("select Nombre,Apellidos,Edad,Sexo,Lugar_nac,Curp,Correo,TelCeluar,TelCasa,Domicilio from alumno where Matricula = " + txtMatricula.Text);
                lbl_msg.Text = "";
                Grv_alumno.DataBind();
                if (obj.Cargar("select 'si' from alumno where Id_doc is null and Matricula = " + txtMatricula.Text) != "si")
                {
                    lbl_pas1.Text = "Entrega de Documento correcto";
                    if (obj.Cargar("select 'si' from alumno where Id_Entrega is null and Matricula = " + txtMatricula.Text) != "si")
                    {
                        lbl_paso2.Text = "Envio de Documentos";
                        if (obj.Cargar("select 'si' from alumno where Folio is null and Matricula = " + txtMatricula.Text) != "si")
                        {
                            lbl_paso3.Text = "Espera de titulo";
                            if (obj.Cargar("select 'si' from alumno where Id_cedula is null and Matricula = " + txtMatricula.Text) != "si")
                            {
                                lbl_titu.Text = "Titulo Listo";
                                lbl_paso2.Text = "---";
                                lbl_paso3.Text = "---";
                                lbl_pas1.Text = "---";
                            }
                            else
                            {

                                lbl_titu.Text = "Espera de Titulo";
                            }
                        }
                        else
                        {
                            lbl_paso3.Text = "Espera de Firma(Estudiante)";
                            lbl_titu.Text = "---";
                        }
                    }
                    else
                    {
                        lbl_paso2.Text = "Espera de firma(Gobernador)";
                        lbl_paso3.Text = "---";
                        lbl_titu.Text = "---";
                    }
                }
                else
                {
                    lbl_pas1.Text = "Falta entrega de Documento";
                    lbl_paso2.Text = "---";
                    lbl_paso3.Text = "---";
                    lbl_titu.Text = "---";

                }

            }
            else
            {
                lbl_msg.Text = "No hay registro de la matricula";
            }
        }
    }
}