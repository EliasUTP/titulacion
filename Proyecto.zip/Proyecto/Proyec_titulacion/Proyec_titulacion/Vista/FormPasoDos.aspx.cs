﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace Proyec_titulacion.Vista
{
    public partial class FormPasoDos : System.Web.UI.Page
    {
        Modelo.Pasodos objDos = new Modelo.Pasodos();
        Modelo.Alumno objAlumno = new Modelo.Alumno();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            objDos.FechAuto = txtFechauto.Text;
            objDos.FechEntrega = txtFechdpotitu.Text;
            objDos.FechAcre = txtFechcise.Text;
            objDos.Periodo = txtPeriestadi.Text;
            objDos.Reporte = txtReporte.Text;
            objDos.Empresa = txtEmpresa.Text;
            objDos.Fotos = cmbFotografias.Text;
            objDos.Gastos = txtGastos.Text;
            objDos.Encargado = txtNombre.Text;
            objDos.Matricula = Convert.ToDouble(TextBox1.Text);

            int r = objDos.alta();

            if (r == 1)
                lblDatos.Text = "Datos insertados";

            else
                if (r == 0)
                lblDatos.Text = "No se insertaron datos";

            else
                lblDatos.Text = "Error en la base de datos";

            
            objAlumno.Matricula = Convert.ToDouble(TextBox1.Text);
            objAlumno.IdDos = objAlumno.regresa_pasados(Convert.ToDouble(TextBox1.Text));
            int hr = objAlumno.Actualiza_PasoDos();
            if (hr == 1)
                MessageBox.Show("Actuliazado");
            else if (hr == 0)
                MessageBox.Show("No actulizado");
            else
                MessageBox.Show("ERROR POR SUBNORMAL");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            lblNombre.Text = objAlumno.regresa_nombre(Convert.ToDouble(TextBox1.Text));
            lblpellidos.Text = objAlumno.regresa_apellidos(Convert.ToDouble(TextBox1.Text));
        }
    }
}