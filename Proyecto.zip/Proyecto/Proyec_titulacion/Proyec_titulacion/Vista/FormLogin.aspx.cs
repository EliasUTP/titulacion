﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Proyec_titulacion.Vista
{
    public partial class FormLogin : System.Web.UI.Page
    {
        Controlador.Conexion ML = new Controlador.Conexion();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnEntrar_Click(object sender, EventArgs e)
        {
            if (ML.Conectar() == true)
            {
                SqlConnection con = new SqlConnection("Data source = Marcos; Initial catalog = Titulacion; Integrated security = true");
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from  Usuario where NomUser='" + txtUsuario.Text + "' and Contraseña ='" + txtContraseña2.Text + "'", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    Response.Redirect("FormAlumno.aspx");
                }
                else
                {
                    lblLogin.Text = "Usuario o Contraseña incorrectos !!";
                }

            }
        }
    }
}